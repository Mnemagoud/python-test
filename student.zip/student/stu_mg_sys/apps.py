from django.apps import AppConfig


class StuMgSysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stu_mg_sys'

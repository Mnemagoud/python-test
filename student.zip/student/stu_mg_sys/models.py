from django.db import models
from unittest.util import _MAX_LENGTH


class student(models.Model):
    name = models.CharField(max_length=40)
    marks = models.IntegerField
    rolno = models.IntegerField(primary_key = True)
    percentage = models.FloatField
    attendence = models.IntegerField

class delete(models.Model):
    member = models.CharField

class Attendance(models.Model):
    rolno= models.IntegerField
    current_attendance = models.IntegerField(null=False, default=00)
    percentage = models.FloatField


# Create your models here.

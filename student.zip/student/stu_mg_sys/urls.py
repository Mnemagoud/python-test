from stu_mg_sys import views
from django.urls import URLPattern, path
urlpatterns = [
    path('student/',views.stud,name="student"),
    path('dlt/',views.dlt,name="student")
]
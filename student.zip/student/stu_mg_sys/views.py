from django.shortcuts import render
from .models import student
from django.contrib.auth.models import User
from django.http import HttpResponse
# Create your views here.

def stud(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        marks = request.POST.get("marks")
        rolno = request.POST.get("rolno")
        attendence = request.POST.get("attendence")
        percent = request.POST.get("percentage")
        b = student(name,marks,rolno,attendence,percent)
        b.save()
    else:
        return render(request,"page1.html",context={})  
    return HttpResponse('created student')


def dlt(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        rolno = request.POST.get("rolno")
        d = delete(name,rolno)
        d.save()
        return HttpResponse("deleted")





